#!/bin/bash

killall conky

conky -c ~/.conky/conkyrc_clean_rings_6cpu ;

exit 0
