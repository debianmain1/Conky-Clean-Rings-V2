#!/bin/bash

killall conky

conky -c ~/.conky/conkyrc_clean_rings ;

exit 0
